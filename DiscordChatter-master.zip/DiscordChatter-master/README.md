# DiscordChatter

Discord chat bot the users both wit.ai and a message scanner to create smart replies to user's messages
